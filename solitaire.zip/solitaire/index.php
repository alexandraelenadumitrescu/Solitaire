<!DOCTYPE html>
<html lang="ro">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pagina de start Solitaire</title>
</head>
<body>
    <h1>Bine ai venit pe site-ul Solitaire!</h1>
    <p>Acesta este un mesaj de test pentru a verifica funcționarea corectă a proiectului.</p>
</body>
</html>
